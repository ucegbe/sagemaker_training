import logging
import os
import shutil
from typing import Optional


JS_INFERENCE_CODE_DIR = "js_inference_code"
CODE_DIR = "code"


def copy_inference_code(dst_path: str, src_path: Optional[str] = None, as_code_dir: bool = True) -> None:
    """Copies the prepacked JS inference code to the specified destination path (optionally as 'code' dir).

    If no src_path specified, it is assumed to be 'js_inference_code' dir relative to the current working dir.
    """
    if not src_path:
        src_path = JS_INFERENCE_CODE_DIR
    if not os.path.exists(src_path):
        logging.info(f"Prepacked inference code at {src_path} does not exist, will not copy into fine-tuned artifact.")
        return
    if as_code_dir:
        dst_path = os.path.join(dst_path, CODE_DIR)
    shutil.copytree(src_path, dst_path)
